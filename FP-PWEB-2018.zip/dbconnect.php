<?php
	$con = mysqli_connect("localhost", "root", "") or die (mysql_error());
	mysqli_select_db($con, "vkvxweok_fp05111640000004") or die (mysql_error());
?>